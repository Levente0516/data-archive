﻿namespace Map
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Map");

            Menu test = new();
            test.Run();
        }
    }
}
