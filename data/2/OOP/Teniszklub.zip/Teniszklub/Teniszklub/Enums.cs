﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Teniszklub
{
    public class Enums
    {
        public Enums() 
        {
            
        }

        public enum Palya_tipus
        {
            fu,             
            salak,          
            muanyag         
        }

        public enum Jatekos_tipus
        {
            igazolt_sportolo,   
            diak,               
            nyugdijas           
        }
    }
}
