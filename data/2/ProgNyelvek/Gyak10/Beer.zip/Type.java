public enum Type
{
    BOTTELED,
    CANNED,
    KEGGD;
}