public class SizeMain
{
    public static void main(String[] args)
    {
        Size example = Size.SMALL;
        
        System.out.println("String of example: " + example.toString());

        System.out.println("Integer of example: " + example.ordinal());
    }
}