public enum Size
{
    SMALL,  // 0
    MEDIUM,  // 1
    LARGE   // 2
}

