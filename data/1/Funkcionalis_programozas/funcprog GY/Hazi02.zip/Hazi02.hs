module Hazi02 where

    --Hazi01

    cmpRem5Rem7 :: Int -> Bool 
    cmpRem5Rem7 x = ((x `mod` 5) >= (x `mod` 7))
    

    foo :: Int -> Bool -> Bool
    foo x y = (x > 0) && y

    bar :: Bool -> Int -> Bool
    bar z u = foo u z 
    
    --Hazi02

    addV :: (Double,Double) -> (Double,Double) -> (Double,Double)
    addV (a1,a2) (b1, b2) = (a1 + b1 , a2 + b2)

    subV :: (Double,Double) -> (Double,Double) -> (Double,Double)
    subV (a1,a2) (b1,b2) = (a1 - b1 , a2 - b2)

    scaleV :: Double -> (Double,Double) -> (Double,Double)
    scaleV skal (a1, a2) = (a1 * skal, a2 * skal)

    scalar :: (Double,Double) -> (Double,Double) -> Double
    scalar (a1,a2) (b1,b2) = (a1 * b1) + (a2 * b2)

    divides :: Integral a => a -> a -> Bool
    divides x y = y `mod` x == 0

    add :: (Integral a, Integral b, Num c) => a -> b -> c
    add x y = fromIntegral x + fromIntegral y

