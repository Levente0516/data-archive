﻿using ReactiveUI;

namespace ELTE.ImageDownloader.Avalonia.ViewModels;

public abstract class ViewModelBase : ReactiveObject;