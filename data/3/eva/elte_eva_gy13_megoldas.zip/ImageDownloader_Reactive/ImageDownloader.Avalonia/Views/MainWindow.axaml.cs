using Avalonia.Controls;

namespace ELTE.ImageDownloader.Avalonia.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}