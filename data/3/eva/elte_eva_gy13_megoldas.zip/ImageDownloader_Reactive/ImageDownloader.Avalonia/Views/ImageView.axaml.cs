using Avalonia.Controls;

namespace ELTE.ImageDownloader.Avalonia.Views;

public partial class ImageView : UserControl
{
    public ImageView()
    {
        InitializeComponent();
    }
}