using Avalonia.Controls;

namespace ELTE.ImageDownloader.Avalonia.Views;

public partial class ImageWindow : Window
{
    public ImageWindow()
    {
        InitializeComponent();
    }
}