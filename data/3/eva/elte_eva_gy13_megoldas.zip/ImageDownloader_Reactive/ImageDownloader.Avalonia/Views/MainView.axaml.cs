using Avalonia.Controls;

namespace ELTE.ImageDownloader.Avalonia.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}