using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Data.Core.Plugins;
using Avalonia.Markup.Xaml;
using Avalonia.Media.Imaging;
using Avalonia.Platform.Storage;
using ELTE.ImageDownloader.Avalonia.ViewModels;
using ELTE.ImageDownloader.Avalonia.Views;
using MsBox.Avalonia;
using MsBox.Avalonia.Enums;
using System.IO;
using SixLabors.ImageSharp.Formats.Png;
using SixLabors.ImageSharp.PixelFormats;

namespace ELTE.ImageDownloader.Avalonia;

public partial class App : Application
{
    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);

    }

    private TopLevel? TopLevel
    {
        get
        {
            return ApplicationLifetime switch
            {
                IClassicDesktopStyleApplicationLifetime desktop => TopLevel.GetTopLevel(desktop.MainWindow),
                ISingleViewApplicationLifetime singleViewPlatform => TopLevel.GetTopLevel(singleViewPlatform.MainView),
                _ => null
            };
        }
    }

    public override void OnFrameworkInitializationCompleted()
    {
        var mainViewModel = new MainViewModel();
        mainViewModel.ImageSelected += ImageSelected;
        mainViewModel.ErrorOccured += OnErrorOccured;

        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            // Line below is needed to remove Avalonia data validation.
            // Without this line you will get duplicate validations from both Avalonia and CT
            BindingPlugins.DataValidators.RemoveAt(0);
            desktop.MainWindow = new MainWindow
            {
                DataContext = mainViewModel
            };
        }
        else if (ApplicationLifetime is ISingleViewApplicationLifetime singleViewPlatform)
        {
            singleViewPlatform.MainView = new MainView
            {
                DataContext = mainViewModel
            };
        }

        base.OnFrameworkInitializationCompleted();
    }

    private void ImageSelected(object? sender, Bitmap e)
    {
        ImageViewModel viewModel = new ImageViewModel(e, string.Empty);
        viewModel.SaveImage += SaveImage;

        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            ImageWindow window = new ImageWindow()
            {
                DataContext = viewModel
            };
            window.Show(desktop.MainWindow!); // owner megad�sa param�terk�nt
        }
        else if (ApplicationLifetime is ISingleViewApplicationLifetime singleViewPlatform)
        {
            var mainView = singleViewPlatform.MainView;
            viewModel.Close += (sender, e) =>
            {
                singleViewPlatform.MainView = mainView;
            }; // vissza�ll�tjuk a f� n�zetet a k�p megjelen�t� n�zet bez�r�sakor

            singleViewPlatform.MainView = new ImageView
            {
                DataContext = viewModel
            };
        }
    }

    private async void OnErrorOccured(object? sender, string e)
    {
        await MessageBoxManager.GetMessageBoxStandard("Image Downloader", e, ButtonEnum.Ok, Icon.Error).ShowAsync();
    }

    private async void SaveImage(object? sender, Bitmap e)
    {
        if (TopLevel == null)
            return;

        var file = await TopLevel.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions()
        {
            Title = "Save image",
            SuggestedFileName = "download.png",
            FileTypeChoices = new[] { FilePickerFileTypes.ImagePng }
        });

        if (file != null)
        {
            using var stream = new MemoryStream();
            e.Save(stream); // �rjuk adatfolyamba a bitmap-et
            stream.Seek(0, SeekOrigin.Begin); // ugorjunk vissza az adatfolyam elej�re

            using var image = SixLabors.ImageSharp.Image.Load<Rgba32>(stream);
            using var fileStream = await file.OpenWriteAsync();
            await image.SaveAsync(fileStream, new PngEncoder());
            // ments�k PNG-k�nt a k�pet az ImageSharp oszt�lyk�nyvt�r haszn�lat�val
        }
    }
}