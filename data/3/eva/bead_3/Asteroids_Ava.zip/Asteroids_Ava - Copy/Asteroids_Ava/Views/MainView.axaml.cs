﻿using Avalonia.Controls;

namespace Asteroids_Ava.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}
