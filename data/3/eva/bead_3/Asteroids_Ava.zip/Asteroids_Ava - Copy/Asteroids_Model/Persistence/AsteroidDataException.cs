﻿using System;

namespace Asteroids_Model.Persistence
{

    public class AsteroidDataException : Exception
    {

        public AsteroidDataException() { }
    }
}
