﻿namespace ELTE.PingPongGame.Model
{
    public enum Direction { Left, Right, Up, Down }
}
