﻿using System;

namespace Asteroids.Persistence
{

    public class AsteroidDataException : Exception
    {

        public AsteroidDataException() { }
    }
}
